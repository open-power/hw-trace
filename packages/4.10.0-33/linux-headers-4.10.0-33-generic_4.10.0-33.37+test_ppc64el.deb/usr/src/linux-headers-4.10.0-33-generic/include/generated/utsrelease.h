#define UTS_RELEASE "4.10.0-33-generic"
#define UTS_UBUNTU_RELEASE_ABI 33
