/* This file is auto generated, version 37+test */
/* SMP */
#define UTS_MACHINE "ppc64le"
#define UTS_VERSION "#37+test SMP Sat Sep 9 04:20:13 CDT 2017"
#define LINUX_COMPILE_BY "root"
#define LINUX_COMPILE_HOST "perfwsw3.aus.stglabs.ibm.com"
#define LINUX_COMPILER "gcc version 6.3.0 20170406 (Ubuntu 6.3.0-12ubuntu2) "
